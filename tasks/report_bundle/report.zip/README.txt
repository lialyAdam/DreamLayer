# Report Bundle

Hi! 
This report includes everything you need to review the image generation results.

What’s inside:
- `results.csv` — a table with image scores and file paths
- `config.json` — the exact settings used during generation (models, prompts, etc.)
- Grid images — labeled previews of the outputs

Feel free to explore or reuse any part of it. Let me know if anything’s missing!

— Lial
